from urllib import request
import os

# 데이터 변수 선언 ----------------------------
WINE_URL='https://archive.ics.uci.edu/ml/machine-learning-databases/wine-quality/winequality-white.csv'
WINE_CSV='../../DATA/WINE/'    # CSV파일 저장 경로
DEBUG = True

# (1) 데이터 준비 -------------------------------
# URL에서 다운로드
# 데이터 파일 저장 폴더 체크
if not os.path.exists(WINE_CSV): os.makedirs(WINE_CSV)

# 데이터 파일 다운로드
WINE_CSV += 'winequality-white.csv'
if DEBUG: print('WINE_CSV =', WINE_CSV)
request.urlretrieve(WINE_URL, WINE_CSV)

